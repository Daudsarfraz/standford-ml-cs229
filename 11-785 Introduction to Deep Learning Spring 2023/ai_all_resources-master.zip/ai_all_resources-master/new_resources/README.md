# New Resourcecs for Review

https://github.com/vinta/awesome-python


Machine Learning Algorithms from scratch

https://github.com/Gautam-J/Machine-Learning

[Curated NLP Database List of 1000+ Natural Language Processing Datasets](https://metatext.io/datasets)

https://github.com/jwasham/coding-interview-university

https://github.com/aj-ames/Centerface-Deepstream

https://github.com/kyclark/tiny_python_projects

https://github.com/ageron/handson-ml2

https://github.com/visenger/awesome-mlops

https://github.com/garrettj403/SciencePlots

https://github.com/whythawk/data-as-a-science

https://github.com/TheAlgorithms/Python

https://github.com/eugeneyan/applied-ml

https://github.com/Rishit-dagli/Perceiver

https://github.com/aj-ames/Activity-Recognition-TensorRT

### Over 200 figures and diagrams of the most popular deep learning architectures and layers FREE TO USE in your blog posts, slides, presentations, or papers.

https://github.com/dvgodoy/dl-visuals

https://jakevdp.github.io/PythonDataScienceHandbook/

https://github.com/huggingface/autonlp

https://github.com/sayakpaul/Denoised-Smoothing-TF

Maths https://github.com/Developer-Y/cs-video-courses#math-for-computer-scientist

The algorithms https://github.com/TheAlgorithms/Python

https://github.com/open-mmlab/mmdetection/tree/master/configs/fast_rcnn