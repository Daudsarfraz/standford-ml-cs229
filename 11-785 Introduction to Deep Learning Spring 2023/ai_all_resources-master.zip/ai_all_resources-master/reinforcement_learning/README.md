### Reinforcement Learning

- [Reinforcement Learning - David Silver | Deepmind | 2020](https://www.youtube.com/playlist?list=PLEAYkSg4uSQ2S3rHUCqz6W1ZKybVICeSP)

- [Deep Reinforcement Learning Algorithms with PyTorch](https://github.com/p-christ/Deep-Reinforcement-Learning-Algorithms-with-PyTorch)

- [LECTURES: Introduction to Reinforcement Learning - David Silver](https://www.davidsilver.uk/teaching/)

- [BOOK: Reinforcement Learning - An Introduction by Sutton and Barto](https://drive.google.com/open?id=1lsBhr8H_PVnyidewtqduvV4b8wcsnAiH)

- [BOOK: Deep Reinforcement Learning Hands On by Maxim Lapan](https://drive.google.com/open?id=1YJUTUsDy2jQ_du-eoExQkk0miCT2NPRm)
